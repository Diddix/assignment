package com.irembo.apiratelimiter.limiter;

public class EmptyConfig {

}
